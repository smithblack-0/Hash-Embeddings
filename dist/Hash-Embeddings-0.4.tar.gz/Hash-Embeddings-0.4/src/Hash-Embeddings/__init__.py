"""
Hash embedding by YannDubs

Transformed by Chris O'Quinn to work in the modern world
"""

__version__ = "0.4"